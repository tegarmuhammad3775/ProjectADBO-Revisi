﻿using UnityEngine;
using System.Collections;

public class HighScoreScript : MonoBehaviour {

	public static int highScores =0;

}
