﻿using UnityEngine;
using System.Collections;

public class ObstacleParent : MonoBehaviour {

	protected void ObstacleMaker ();
}
